F = 2;
A = 3;
Ti = 0.5;

sim('Project2')