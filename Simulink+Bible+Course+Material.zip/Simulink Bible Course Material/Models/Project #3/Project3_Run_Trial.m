Sim_Time = 100;
b = 1;
k = 20;
F = 1;
M = 1;
sim('Project3_Trial')