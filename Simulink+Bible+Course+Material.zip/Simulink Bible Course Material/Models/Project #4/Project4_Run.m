%% first Simulation
Sim_Time = 20;
F = 1;
M = 1;
b = 1;
k = 20;
sim('Project4');



